This directory contains the Invesense "Motion Driver" version 5.1 for the
Invesense line of Digital Motion Processor-based sensors.

This code has been ported to the ATMEGA328P for use in the nav6 project.

This driver was downloaded from:

  http://www.invensense.com/developers

Note that to download this driver, a Invensense developer account is
required.
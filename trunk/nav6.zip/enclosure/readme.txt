The nav6 enclosure is designed to be printed with standard 3D printer software,
and provides protected enclosure and mounting of the nav6 IMU.

IMU Enclosure Notes.ppt:  Summary of design and a mounting diagram
nav6.stl:                 3D Model (STL Format) of nav6 board
base.stl:                 3D model (STL Format) of enclosure base
lid.stl:                  3D model (STL Format) of enclosure lid
base.STEP:                3D model (STEP Format) of enclosure base
lid.STEP:                 3D model (STEP Format) of enclosure lid